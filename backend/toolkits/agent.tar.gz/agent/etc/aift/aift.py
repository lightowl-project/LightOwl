from settings import settings
import logging.config
import logging
import requests
import tools
import sys

logging.config.dictConfig(settings.LOGGING)
logger = logging.getLogger("log")


def aift_config(aift_server: str, aift_agent_token: str, agent_id: str):
    headers: dict = {
        "api_key": aift_agent_token
    }

    response = requests.get(
        f"{aift_server}/agents/config/{agent_id}",
        verify="/etc/ssl/aift/ca.pem",
        headers=headers
    )

    try:
        response.raise_for_status()
    except Exception:
        if response.status_code == 404:
            logger.info("Agent does not exist. Deleting configuration")

            # Agent does not exist. Empty configuration
            with open("/etc/telegraf/telegraf.d/aift.conf", 'w') as f:
                f.write("")

            with open("/etc/telegraf/telegraf.conf", 'w') as f:
                f.write("")

            cron = CronTab(user='root')
            cron.remove_all()

            tools.stop_telegraf()
        else:
            logger.critical(f"Error when calling AIFT Server. Status Code: {response.status_code} Response: {response.text}")
            raise

    config: list = response.json()
    if tools.inputs_config_file(config):
        logger.info("New configuration. Restarting Telegraf")
        tools.restart_telefraf()
    



if __name__ == "__main__":
    if not len(sys.argv) == 4:
        print(f"Usage: {sys.argv[0]} aift_server agent_id aift_agent_token")
        sys.exit(9)

    aift_server:str = f"https://{sys.argv[1]}/api/v1"
    agent_id:str = sys.argv[2]
    aift_agent_token:str = sys.argv[3]

    aift_config(aift_server, aift_agent_token, agent_id)
