from settings import settings
import logging.config
import subprocess
import logging
import jinja2

logging.config.dictConfig(settings.LOGGING)
logger = logging.getLogger("log")


def telegraf_config_file(aift_server: str, agent_id: str) -> None:
        with open('/etc/aift/templates/telegraf.conf.j2', 'r') as f:
            template = f.read()

        telegraf_template = jinja2.Template(template).render({
            "aift_server": aift_server,
            "agent_id": agent_id
        })

        with open("/etc/telegraf/telegraf.conf", "w") as f:
            f.write(telegraf_template)


def inputs_config_file(config: list) -> None:
        config_file: str = "\n\n".join(config)

        with open("/etc/telegraf/telegraf.d/aift.conf", "r") as f:
            current_file = f.read()
            logger.debug(current_file)
            logger.debug(config_file)
            change = current_file != config_file

        if change:
            with open("/etc/telegraf/telegraf.d/aift.conf", "w") as f:
                f.write(config_file)

            return True

        return False

def stop_telegraf():
    cmd: list = ["/usr/bin/sudo", "-u", "aift", "/usr/bin/sudo", "/usr/sbin/service", "telegraf", "stop"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=subprocess.PIPE)
    status, error = proc.communicate()

    if error:
        raise Exception(error.decode("utf-8"))

    return True


def restart_telefraf():
    cmd: list = ["/usr/bin/sudo", "-u", "aift", "/usr/bin/sudo", "/usr/sbin/service", "telegraf", "restart"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=subprocess.PIPE)
    status, error = proc.communicate()

    if error:
        raise Exception(error.decode("utf-8"))

    return True
    