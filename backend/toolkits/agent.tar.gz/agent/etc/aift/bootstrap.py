#!/usr/bin/env python

from tools import telegraf_config_file, inputs_config_file, restart_telefraf
from ipaddress import IPv4Address
from crontab import CronTab
import requests
import json
import sys
import os


class Bootstrap:
    def __init__(self, aift_token: str, aift_agent_token: str, aift_server: str):
        self.aift_server: str = aift_server
        self.aift_url: str = f"https://{aift_server}/api/v1"
        self.aift_agent_token: str = aift_agent_token
        self.headers: dict = {
            "api_key": aift_token
        }

    def get_aift_config(self, agent_id: str):
        headers: dict = {
            "api_key": self.aift_agent_token,
            "Host": "aift-server"
        }

        response = requests.get(
            f"{self.aift_url}/agents/config/{agent_id}", 
            # verify="/etc/ssl/aift/ca.pem",
            headers=headers,
            verify=False
        )

        try:
            response.raise_for_status()
            return response.text
        except Exception:
            print(response.status_code)
            print(response.text)
            raise


    def join_aift_server(self, tags: list, plugins: dict):
        uname = os.uname()
        device_info: dict = {
            "agent_token": self.aift_agent_token,
            "hostname": uname.nodename,
            "os": uname.sysname,
            "plugins": plugins,
            "tags": tags
        }

        response = requests.post(
            f"{self.aift_url}/agents/join",
            data=json.dumps(device_info),
            headers=self.headers,
            verify=False
        )

        try:
            response.raise_for_status()
            data = response.json()
            print(data)
            # with open("/etc/ssl/aift/aift.ca.pem", 'w') as f:
            #     f.write(data["ca"])
            
            return data["_id"]
        except requests.exceptions.HTTPError:
            if response.status_code == 401:
                print("Invalid API Key")
                self.headers["api_key"] = ""
                while not self.headers["api_key"]:
                    self.headers["api_key"] = input("AIFT Token: ")
                
                return self.join_aift_server(tags, plugins)
            else:
                print(response.text)
                raise
    
    def install_crontab(self, agent_id: str):
        cron = CronTab(user='root')
        cron.remove_all()

        job = cron.new(f"/etc/aift/env/bin/python /etc/aift/aift.py {self.aift_server} {agent_id} {self.aift_agent_token}")
        job.minute.every(1)
        cron.write()


def read_config_file() -> dict:
    with open("/etc/aift/config.json", "r") as f:
        config: dict = json.loads(f.read())

    IPv4Address(config["aift_server"])
    return config
    


def install():
    print("""
░█████╗░██╗███████╗████████╗
██╔══██╗██║██╔════╝╚══██╔══╝
███████║██║█████╗░░░░░██║░░░
██╔══██║██║██╔══╝░░░░░██║░░░
██║░░██║██║██║░░░░░░░░██║░░░
╚═╝░░╚═╝╚═╝╚═╝░░░░░░░░╚═╝░░░""")
    print("\nThank you for using AIFT")
    print("Agent configuration\n")

    try:
        config: dict = read_config_file()
    except Exception:
        print("Invalid config file")
        sys.exit(9)

    bootstrap = Bootstrap(
        config["api_key"],
        config["agent_token"],
        config["aift_server"]
    )

    agent_id: str = bootstrap.join_aift_server(
        config["tags"],
        config["plugins"]
    )

    aift_config: list = json.loads(bootstrap.get_aift_config(agent_id))

    telegraf_config_file(config["aift_server"], agent_id)
    if inputs_config_file(aift_config):
        restart_telefraf()

    bootstrap.install_crontab(agent_id)


if __name__ == "__main__":
    install()
