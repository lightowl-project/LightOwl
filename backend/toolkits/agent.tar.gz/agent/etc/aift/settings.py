from pydantic import BaseSettings


class LogSettings(BaseSettings):
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "/var/log/aift/aift.log"
    LOGGING_FORMAT = '{"date": "%(asctime)s", "level": "%(levelname)s", "name": "%(name)s", "module":"%(module)s", "line_number": %(lineno)s, "message": "%(message)s"}'

    LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        "verbose": {
            "format": LOGGING_FORMAT,
            "datefmt": "%Y-%m-%dT%H:%M:%S%z"
        },
        "simple": {
            "format": "[%(levelname)s] [<%(name)s>:%(module)s:%(lineno)s] "
                      "%(message)s"
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'verbose'
        },
        'debug': {
            'level': LOG_LEVEL,
            'class': 'logging.FileHandler',
            'filename': LOG_FILE,
            'formatter': 'verbose'
        },
    },
    'loggers': {
        'log': {
            'handlers': ['debug', 'console'],
            'level': LOG_LEVEL
        }
    }
}


class Settings(LogSettings):
    pass

settings = Settings()
